import { TdAvatarGroupProps } from './type';
declare const props: TdAvatarGroupProps;
export default props;
