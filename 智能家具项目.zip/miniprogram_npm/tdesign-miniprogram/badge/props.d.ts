import { TdBadgeProps } from './type';
declare const props: TdBadgeProps;
export default props;
