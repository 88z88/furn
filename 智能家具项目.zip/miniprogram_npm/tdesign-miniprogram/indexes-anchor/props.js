const props = {
    externalClasses: {
        type: Array,
    },
    index: {
        type: null,
    },
};
export default props;
