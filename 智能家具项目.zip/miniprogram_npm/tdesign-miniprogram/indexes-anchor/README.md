:: BASE_DOC ::

## API
### IndexesAnchor Props

名称 | 类型 | 默认值 | 说明 | 必传
-- | -- | -- | -- | --
external-classes | Array | - | 组件类名，用于设置组件外层元素类名。`['t-class']` | N
index | String / Number | - | 索引字符 | N
