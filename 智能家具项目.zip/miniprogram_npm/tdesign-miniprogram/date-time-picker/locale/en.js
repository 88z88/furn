export default {
    year: '',
    month: '',
    date: '',
    hour: '',
    minute: '',
    second: '',
    am: 'AM',
    pm: 'PM',
    confirm: 'confirm',
    cancel: 'cancel',
};
