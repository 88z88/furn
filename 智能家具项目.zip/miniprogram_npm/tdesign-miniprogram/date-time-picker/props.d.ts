import { TdDateTimePickerProps } from './type';
declare const props: TdDateTimePickerProps;
export default props;
