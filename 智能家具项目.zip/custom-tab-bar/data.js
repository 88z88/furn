export default [
  {
    icon: 'home',
    text: '首页',
    url: 'pages/home/home',
  },
  {
    icon: 'person',
    text: '个人中心',
    url: 'pages/usercenter/index',
  },
];
